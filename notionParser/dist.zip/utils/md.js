import markdownTable from "markdown-table";
import colorToStyle from "./colorToStyle.js";
export const inlineCode = (text) => {
    return `\`${text}\``;
};
export const inlineEquation = (text) => {
    return `$${text}$`;
};
export const bold = (text) => {
    return `**${text}**`;
};
export const italic = (text) => {
    return `*${text}*`;
};
export const strikethrough = (text) => {
    return `~~${text}~~`;
};
export const underline = (text) => {
    return `<u>${text}</u>`;
};
export const link = (text, href) => {
    return `[${text}](${href})`;
};
export const codeBlock = (text, language) => {
    if (language === "plain text")
        language = "text";
    return `\`\`\`${language}
${text}
\`\`\``;
};
export const equation = (text) => {
    return `$$
${text}
$$`;
};
export const heading1 = (text, color) => {
    return color !== 'default' ? `# <span style="${colorToStyle(color)}">${text}</span>` : `# ${text}`;
};
export const heading2 = (text, color) => {
    return color !== 'default' ? `## <span style="${colorToStyle(color)}">${text}</span>` : `## ${text}`;
};
export const heading3 = (text, color) => {
    return color !== 'default' ? `### <span style="${colorToStyle(color)}">${text}</span>` : `### ${text}`;
};
export const quote = (text, color) => {
    // the replace is done to handle multiple lines
    return color !== 'default' ? `> <span style="${colorToStyle(color)}">${text.replace(/\n/g, "  \n> ")}</span>` : `> ${text.replace(/\n/g, "  \n> ")}`;
};
export const callout = (text, icon) => {
    let emoji;
    if (icon?.type === "emoji") {
        emoji = icon.emoji;
    }
    // the replace is done to handle multiple lines
    return `> ${emoji ? emoji + " " : ""}${text.replace(/\n/g, "  \n> ")}`;
};
export const bullet = (text, color, count) => {
    let renderText = text.trim();
    return color !== 'default' ? count ? `${count}. <span style="${colorToStyle(color)}">${renderText}</span>` : `- <span style="${colorToStyle(color)}">${renderText}</span>` : count ? `${count}. ${renderText}` : `- ${renderText}`;
};
export const todo = (text, color, checked) => {
    return color !== 'default' ? checked ? `- <span style="${colorToStyle(color)}">[x] ${text}</span>` : `- <span style="${colorToStyle(color)}">[ ] ${text}</span>` : checked ? `- [x] ${text}` : `- [ ] ${text}`;
};
export const image = (alt, href) => {
    return `![${alt}](${href})`;
};
export const addTabSpace = (text, n = 0) => {
    const tab = "	";
    for (let i = 0; i < n; i++) {
        if (text.includes("\n")) {
            const multiLineText = text.split(/(?<=\n)/).join(tab);
            text = tab + multiLineText;
        }
        else
            text = tab + text;
    }
    return text;
};
export const divider = () => {
    return "---";
};
export const toggle = (summary, children) => {
    if (!summary)
        return children || "";
    return `<details>
  <summary>${summary}</summary>

${children || ""}

  </details>`;
};
export const table = (cells) => {
    return markdownTable(cells);
};
