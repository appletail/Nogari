import { NotionToMarkdown } from "notion-to-md";
import setCustomMarkdown from "./setCustomMarkdown.js";
const customNotionToMarkdown = (notionClient) => {
    const n2m = new NotionToMarkdown({ notionClient });
    const custom_n2m = setCustomMarkdown(n2m);
    return custom_n2m;
};
export default customNotionToMarkdown;
